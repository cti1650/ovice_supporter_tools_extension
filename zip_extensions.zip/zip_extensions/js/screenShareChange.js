;((global) => {
    const ovice = global.oviceConnecter()
    // console.log('onClick ScreenShare')
    ovice.screenShare()
})(window)
