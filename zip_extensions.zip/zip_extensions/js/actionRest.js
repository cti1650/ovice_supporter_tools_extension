;((global) => {
    const ovice = global.oviceConnecter()
    // console.log('onClick actionRest')
    ovice.rest()
})(window)
